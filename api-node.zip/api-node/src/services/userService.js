const bcrypt = require('bcrypt');
const userRepository = require('../repositories/userRepository');
const { v4: UUIDV4 } = require('uuid')

const SECRET_KEY = 'chave_secreta'

class UserService{
    async getAll(){
        return userRepository.findAll();
    }

    async getByUserName(username){
        return userRepository.findByUserName(username);
    }

    async register(username, password){
        if(username === ""){
            throw new Error('Preencha o username!');
        }

        if(password === ""){
            throw new Error('Preencha a senha!');
        }

        const user = await this.getByUserName(username);

        if(user){
            throw new Error('Username indisponivel');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const id = UUIDV4();
        return await userRepository.createUser({
            id,
            username,
            password: hashedPassword
        });
    }
}

module.exports = new UserService();