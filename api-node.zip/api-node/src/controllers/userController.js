const express = require('express');
const userService = require('../services/userService')

const router = express.Router();

router.get('/', async(req, res) =>{
    const users = userService.getAll();
    try{
        const users = await userService.getAll();
    res.json(users);
    }catch(err){
        res.status(400).json({erro: err.message})
    }
});

router.post('/', async(req, res) =>{
        const {username, password} = req.body;
        const user = await userService.register(username, password);
        res.json(user);

})

module.exports = router;