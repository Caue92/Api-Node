const { Sequelize, DataTypes } = require('sequelize')
const sequelize = require('../config/database')

const card = sequelize.define('card',
    {
        Ataque:{
            type: DataTypes.INTEGER,
            primaryKey: true
        },
        Defesa:{
            type: DataTypes.INTEGER,
            allowNull: false
        },
        Nivel: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        Custo: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        NomeDoCard: {
            type: DataTypes.STRING,
            allowNull: false
        },
        Descricao: {
            type: DataTypes.STRING,
            allowNull: false
        },
        UrlImagem: {
            type: DataTypes.STRING,
            allowNull: false
        }
      
    }
)

module.exports = card;