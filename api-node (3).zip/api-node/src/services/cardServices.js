const bcrypt = require('bcrypt');
const userRepository = require('../repositories/userRepository');
const { v4: UUIDV4 } = require('uuid')
const jwt = require('jsonwebtoken');


class cardService{
    async getAll(){
        return cardServiceRepository.findAll();
    }

    async getBycardName(cardname){
        return userRepository.findByUserName(cardname);
    }

    async register(Ataque, defesa, nivel, custo, nome, descricao, UrlImagem){
        if(ataque < 0 || ataque > 10){
            throw new Error('ataque invalido: tente novamente');
        }
        const card = await this.getByUserName(cardname);

        {if(defesa <0 || defesa>10){
            throw new Error('defesa invalida:tente novamente');
        }
          
        if(nivel <1 || nivel>10 ){
        throw new Error('nivel invalido: tente novamente');
        }

        {
          if(custo <1 || custo>10){
            throw new Error('custo invalido: tente novamente');
          }
            if(nome === ""|| nome.lengh <1|| nome.lengh> 50) {
                throw new Error('nome invalido: tente novamente')

            }
        }
            
        
    }
        const id = UUIDV4();
        return await cardServiceRepository.createUser({
            id,
            cardname,
        });
    }

    async login(username, password){
        const user = await this.getByUserName(cardname);
        if(!user){
            throw new Error('Usuário ou Senha Inválidos');
        }

        const isValidPassword = await bcrypt.compare(password, user.password);
        if(!isValidPassword){
            throw new Error('Usuário ou Senha Inválidos');

        }
        const token = jwt.sign({id: user.id}, SECRET_KEY, {expiresIn:'1h'})
        return token; 


    }

    async delete(username){
        const user = await this.getByUserName(username);

        if(!user){
            throw new Error('Usuário inválido');
        }

        userRepository.delete(user.id);
    }
}


module.exports = new UserService();