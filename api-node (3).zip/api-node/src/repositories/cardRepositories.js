const card = require('../model/user');

class UserRepository {
    async createCard(card){
        return await card.create(card);
    }

    async findAll(){
        return await card.findAll();
    }

    async findByUserName(nomedacarta){
        return await card.findOne({ where: {nomedacarta}})
    }
    async delete(id){
        await card.destroy({where: {id}})
    }
}



module.exports = new cardRepository();